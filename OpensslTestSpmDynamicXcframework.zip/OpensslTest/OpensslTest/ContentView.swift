//
//  ContentView.swift
//  OpensslTest
//
//  Created by Steve McCoole on 8/3/20.
//  Copyright © 2020 block.one. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
