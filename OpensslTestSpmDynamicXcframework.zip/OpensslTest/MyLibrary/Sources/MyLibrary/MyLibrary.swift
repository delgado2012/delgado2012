struct MyLibrary {
    var text = "Hello, World!"
}
